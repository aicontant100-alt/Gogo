import {db,json,adminFrom} from "./_lib.js";
import {randomBytes} from "node:crypto";
export default async function handler(req,res){
  if(req.method!=="POST") return json(res,405,{error:"Method not allowed"});
  try{
    const admin=await adminFrom(req); if(!admin) return json(res,403,{error:"Admin access required"});
    const days=Number(req.body?.duration_days), qty=Number(req.body?.quantity);
    if(![1,7,30,36500].includes(days)||!Number.isInteger(qty)||qty<1||qty>50) return json(res,400,{error:"Invalid duration or quantity"});
    const rows=Array.from({length:qty},()=>({key:`NEXUS-${randomBytes(3).toString("hex").toUpperCase()}-${randomBytes(3).toString("hex").toUpperCase()}-${randomBytes(3).toString("hex").toUpperCase()}`,status:"unused",expires_at:days===36500?null:new Date(Date.now()+days*86400000).toISOString(),created_by:admin.id}));
    const {error}=await db.from("licenses").insert(rows); if(error) throw error;
    return json(res,200,{created:rows.length});
  }catch(e){return json(res,500,{error:"Could not create licenses"});}
}