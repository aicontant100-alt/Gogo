import { createClient } from "@supabase/supabase-js";
export const db = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {auth:{persistSession:false}});
export function json(res,status,body){res.status(status).setHeader("Content-Type","application/json").json(body);}
export async function userFrom(req){
  const token=(req.headers.authorization||"").replace(/^Bearer\s+/i,"");
  if(!token) return null;
  const {data,error}=await db.auth.getUser(token);
  return error?null:data.user;
}
export async function adminFrom(req){
  const user=await userFrom(req); if(!user) return null;
  const {data}=await db.from("profiles").select("role").eq("id",user.id).single();
  return data?.role==="admin"?user:null;
}