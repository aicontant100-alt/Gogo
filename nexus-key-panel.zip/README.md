# NEXUS KEY PANEL

A responsive React license dashboard with Supabase Auth/Postgres and Vercel serverless API routes.

## Features
- User signup/signin using Supabase Auth
- User sees licenses assigned to their account
- Admin-only key generation, ban/unban and HWID reset
- Server-side license verification endpoint for an Android app
- HWID/device binding on first successful verification

## 1. Create Supabase project
1. Create a project at https://supabase.com/.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Authentication > URL Configuration, set your deployed Vercel URL as Site URL and add localhost during development.
4. Copy Project URL, anon/public key, and service_role key from Project Settings > API.
5. Create your admin account by signing up through the panel. Then run:
   `update public.profiles set role='admin' where email='YOUR_ADMIN_EMAIL';`
   Do not expose service_role key.

## 2. Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local`.
3. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. Set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to the same project URL and service-role secret.
5. Run `npm install` then `npm run dev`.

Vite does not run Vercel API routes locally by itself. For full local API testing, use Vercel CLI:
`npm i -g vercel`
`vercel dev`

## 3. Deploy to Vercel free tier
1. Push this project to a private GitHub repository.
2. Import the repository at https://vercel.com/new.
3. Framework preset: Vite.
4. Add all four environment variables from `.env.example` in Vercel Project Settings > Environment Variables.
5. Deploy. Redeploy after changing environment variables.
6. Set the Vercel domain as Supabase Auth Site URL and add it to Redirect URLs.

## 4. Admin setup
Register a normal account first. In Supabase SQL Editor, promote only your own account:
`update public.profiles set role='admin' where email='YOUR_ADMIN_EMAIL';`
Sign out and sign in again, then reload the dashboard.

## 5. Assign a generated key to a user
The admin dashboard generates keys. To attach a key to a user account, use the Supabase SQL Editor:
`update public.licenses set user_id=(select id from auth.users where email='USER_EMAIL') where key='NEXUS-XXXXXX-XXXXXX-XXXXXX';`
The user will then see that key in their dashboard.

## 6. Android integration
See `android/LicenseVerifier.java`. Call `verify()` on a background thread and allow access only when `valid == true`. Add the Android permission:
`<uses-permission android:name="android.permission.INTERNET" />`
Use `Settings.Secure.ANDROID_ID` as a basic device identifier. It is not tamper-proof and can change after resets or under some device/profile conditions. For stronger integrity, consider Play Integrity API and additional server-side abuse controls.

## Important security notes
- Never commit `.env.local` or service-role credentials.
- The service-role key bypasses RLS; it belongs only in Vercel server environment variables.
- Frontend code is not a security boundary. All license decisions must happen on the server.
- This starter does not implement payment processing, offline activation, or tamper-proof HWID.
- Add rate limiting/WAF, monitoring, audit logs and email verification before production use.
- A key is initially unassigned. Link it to a user via the SQL step above; the sample verification endpoint binds its first device.
- The admin stats view is intended for service-role access. Do not grant anonymous/public access to it.
