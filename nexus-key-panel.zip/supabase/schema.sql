-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  status text not null default 'unused' check (status in ('unused','active','expired','banned')),
  expires_at timestamptz,
  hwid text,
  user_id uuid references auth.users(id) on delete set null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists licenses_key_idx on public.licenses(key);
create index if not exists licenses_user_id_idx on public.licenses(user_id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,email) values(new.id,new.email)
  on conflict (id) do update set email=excluded.email;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.licenses enable row level security;

drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles for select to authenticated using (id=auth.uid());
drop policy if exists "read own licenses" on public.licenses;
create policy "read own licenses" on public.licenses for select to authenticated using (user_id=auth.uid());

-- Admin stats are queried through the service-role API only.
create or replace view public.admin_stats as
select count(*)::int as total_keys,
count(*) filter (where status='active')::int as active_keys,
count(*) filter (where status='banned')::int as banned_keys
from public.licenses;
