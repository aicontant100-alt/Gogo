// Example Android client integration (Java).
// Use your deployed Vercel URL. Never put Supabase service-role credentials in an APK.
package com.example.yourapp;

import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public final class LicenseVerifier {
    public interface Callback { void onResult(boolean valid, String message); }

    public static void verify(String apiBase, String licenseKey, String androidId, Callback callback) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(apiBase + "/api/verify");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");
                JSONObject payload = new JSONObject();
                payload.put("key", licenseKey);
                payload.put("hwid", androidId);
                try (OutputStream out = connection.getOutputStream()) {
                    out.write(payload.toString().getBytes("UTF-8"));
                }
                int code = connection.getResponseCode();
                InputStream stream = code < 400 ? connection.getInputStream() : connection.getErrorStream();
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024]; int n;
                while ((n = stream.read(buffer)) > 0) bytes.write(buffer, 0, n);
                JSONObject result = new JSONObject(bytes.toString("UTF-8"));
                boolean valid = result.optBoolean("valid", false);
                String message = result.optString("error", valid ? "License active" : "Verification failed");
                callback.onResult(valid, message);
            } catch (Exception e) {
                callback.onResult(false, "Unable to contact license server");
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }
}